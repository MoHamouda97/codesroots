import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mobile-codesroots',
  templateUrl: './mobile-codesroots.component.html',
  styleUrls: ['./mobile-codesroots.component.css']
})
export class MobileCodesrootsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
