import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'desktop-codesroots',
  templateUrl: './desktop-codesroots.component.html',
  styleUrls: ['./desktop-codesroots.component.css']
})
export class DesktopCodesrootsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
