import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'marketing-service',
  templateUrl: './marketing-service.component.html',
  styleUrls: ['./marketing-service.component.css']
})
export class MarketingServiceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
