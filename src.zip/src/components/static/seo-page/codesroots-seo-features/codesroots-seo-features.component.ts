import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'codesroots-seo-features',
  templateUrl: './codesroots-seo-features.component.html',
  styleUrls: ['./codesroots-seo-features.component.css']
})
export class CodesrootsSeoFeaturesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
