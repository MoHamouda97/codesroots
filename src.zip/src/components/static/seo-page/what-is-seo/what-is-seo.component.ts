import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'what-is-seo',
  templateUrl: './what-is-seo.component.html',
  styleUrls: ['./what-is-seo.component.css']
})
export class WhatIsSeoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
