import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'contact-phone',
  templateUrl: './contact-phone.component.html',
  styleUrls: ['./contact-phone.component.css']
})
export class ContactPhoneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
