import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'seo-service',
  templateUrl: './seo-service.component.html',
  styleUrls: ['./seo-service.component.css']
})
export class SeoServiceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
