import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-desktop-page',
  templateUrl: './desktop-page.component.html',
  styleUrls: ['./desktop-page.component.css']
})
export class DesktopPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
