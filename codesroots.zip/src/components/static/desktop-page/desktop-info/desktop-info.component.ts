import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'desktop-info',
  templateUrl: './desktop-info.component.html',
  styleUrls: ['./desktop-info.component.css']
})
export class DesktopInfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
