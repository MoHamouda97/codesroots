import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'desktop-intro',
  templateUrl: './desktop-intro.component.html',
  styleUrls: ['./desktop-intro.component.css']
})
export class DesktopIntroComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
