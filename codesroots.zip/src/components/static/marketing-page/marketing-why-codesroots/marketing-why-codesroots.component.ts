import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'marketing-why-codesroots',
  templateUrl: './marketing-why-codesroots.component.html',
  styleUrls: ['./marketing-why-codesroots.component.css']
})
export class MarketingWhyCodesrootsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
