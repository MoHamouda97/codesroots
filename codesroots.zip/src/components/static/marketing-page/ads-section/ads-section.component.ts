import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ads-section',
  templateUrl: './ads-section.component.html',
  styleUrls: ['./ads-section.component.css']
})
export class AdsSectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
