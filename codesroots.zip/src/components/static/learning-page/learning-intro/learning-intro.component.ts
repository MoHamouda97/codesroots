import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'learning-intro',
  templateUrl: './learning-intro.component.html',
  styleUrls: ['./learning-intro.component.css']
})
export class LearningIntroComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
