import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mobile-intro',
  templateUrl: './mobile-intro.component.html',
  styleUrls: ['./mobile-intro.component.css']
})
export class MobileIntroComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
