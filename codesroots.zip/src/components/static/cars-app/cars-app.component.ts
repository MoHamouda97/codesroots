import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cars-app',
  templateUrl: './cars-app.component.html',
  styleUrls: ['./cars-app.component.css']
})
export class CarsAppComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
