import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'why-codesroots',
  templateUrl: './why-codesroots.component.html',
  styleUrls: ['./why-codesroots.component.css']
})
export class WhyCodesrootsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
