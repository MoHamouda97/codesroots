import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'web-design-section',
  templateUrl: './web-design-section.component.html',
  styleUrls: ['./web-design-section.component.css']
})
export class WebDesignSectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
