import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'shop-intro',
  templateUrl: './shop-intro.component.html',
  styleUrls: ['./shop-intro.component.css']
})
export class ShopIntroComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
