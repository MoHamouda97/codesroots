import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'shop-codesroots',
  templateUrl: './shop-codesroots.component.html',
  styleUrls: ['./shop-codesroots.component.css']
})
export class ShopCodesrootsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
