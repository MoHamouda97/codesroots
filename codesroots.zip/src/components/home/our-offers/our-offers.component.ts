import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'our-offers',
  templateUrl: './our-offers.component.html',
  styleUrls: ['./our-offers.component.css']
})
export class OurOffersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
