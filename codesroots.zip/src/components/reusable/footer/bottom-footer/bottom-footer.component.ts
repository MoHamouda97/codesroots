import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'bottom-footer',
  templateUrl: './bottom-footer.component.html',
  styleUrls: ['./bottom-footer.component.css']
})
export class BottomFooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
