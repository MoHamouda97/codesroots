import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-socil-media',
  templateUrl: './socil-media.component.html',
  styleUrls: ['./socil-media.component.css']
})
export class SocilMediaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
